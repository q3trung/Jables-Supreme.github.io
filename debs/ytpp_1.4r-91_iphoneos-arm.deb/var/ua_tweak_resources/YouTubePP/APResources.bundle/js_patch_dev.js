defineClass('NSArray', {
    array: function() {
        return self;
    },
});